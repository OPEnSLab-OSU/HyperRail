exports.connect = () => {
    return new Promise((resolve, reject) => {
        if(client == null) {
            client = new Influx.InfluxDB(metadata);
            client.createDatabase(dbName)
                .then(() => resolve(`${dbUrl}:${dbPort}`))
                .catch((err) => reject(err));
        } else {
            reject('DB connection already established');
        }
    });
};