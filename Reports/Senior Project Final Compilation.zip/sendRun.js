router.post('/execute', (req, res) => {
    let config = req.body;
    const address = ip.address();
	
	/*
	Config missing total steps, delaytime, intervalSteps
	CALCULATIONS TAKEN FROM THE PROCESSING CODE
	
	Delay time = ((60)/(RPM * steps_per_revolution ) * pow(10, 6))/2;
	steps_per_revolution = 6180
	RPM = (velocity * 60) / (2 * 3.1415926535 * spoolRadius(mm))
	
	Total Steps = (steps_per_revolution * path_length (mm)) / (2 * 3.1415926535 * spoolRadius)
	Interval Steps = (steps_per_revolution * interval_length (mm)) / (2 * 3.1415926535 * spoolRadius) 
	*/
	let steps_per_revolution = 6180;
	let RPM = (config.velocity * 60) / (2 * 3.1415926535 * parseFloat(config.spoolRadius));
	let delayTime = (60 / (RPM * steps_per_revolution) * Math.pow(10, 6)) / 2;
	
	let totalSteps = (steps_per_revolution * (parseFloat(config.railLength) * 1000)) / (2 * 3.1415926535 * parseFloat(config.spoolRadius));
	let intervalSteps = (steps_per_revolution * (parseFloat(config.intervalDistance) * 1000)) / (2 * 3.1415926535 * parseFloat(config.spoolRadius));
	
	config.delayTime = parseInt(delayTime);
	config.totalSteps = parseInt(totalSteps);
	config.intervalSteps = parseInt(intervalSteps);
	
	logger.ok("Sent to hardware:\n" + JSON.stringify(config));
	
    if(!address) {
        logger.error('IP Address for the host could not be found');
        const status = 500;
        const msg = logger.buildPayload(logger.level.ERROR, 'Could not find host IP Address programmatically');
        res.status(status).send(msg);
    } else {
        config.ipAddress = address;
        axios.post(`http://${botAddress}/execute`, config)
            .then((botRes) => {
                const str = 'Config uploaded to bot, executing...';
                logger.ok(str);
                let status, msg;
                if(botRes.data.Status === "Received") {
                    status = 200;
                    msg = logger.buildPayload(logger.level.OK, str);
                } else {
                    status = 500;
                    msg = logger.buildPayload(logger.level.ERROR, 'Connected to bot, but upload failed');
                }
                res.status(status).send(msg);
            })
            .catch((err) => {
                const str = 'Error uploading config to bot';
                logger.error(`${str}: ${err}`);
                const status = 500;
                const msg = logger.buildPayload(logger.level.ERROR, str);

                res.status(status).send(msg);
            });
    } 
});