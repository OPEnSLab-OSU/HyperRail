function executeRun() {
	var err = "";	//Strings to store error messages
	var optErr = "";
	var numErr = "";
	
	
	if($.trim($("#runNameInput").val()) == "")
		err += "Run Name, ";
	if($.trim($("#botNameInput").val()) == "")
		err += "Bot Name, ";
	
	if($("#modifyIntervalFlag").prop("checked") == false)	//Convert Interval flag checkbox status to integer
		var intervalFlag = 0;
	else
		var intervalFlag = 1;
		
	if($("#modifyOption").val() == "")					//Check if the option number is empty
		err += "Option, ";
	else if ($("#modifyOption").val() < 1 || $("#modifyOption").val() > 5)	//If not empty, check if it is between 1 and 5
		optErr += "Option must be an integer between 1 and 5.\n";
	
	if($("#modifyRailLength").val() == "")				//Check if the Rail Length is empty
		err += "Rail Length, ";
	else if ($("#modifyRailLength").val() <= 0)			//If not empty, check if it is 0 or less
		numErr += "Rail Length, ";
	
	if($("#modifySpoolRadius").val() == "")				//Check if the Spool Radius is empty
		err += "Spool Radius, ";
	else if ($("#modifySpoolRadius").val() <= 0)		//If not empty, check if it is 0 or less
		numErr += "Spool Radius, ";
	
	if($("#modifyVelocity").val() == "")				//Check if the Velocity is empty
		err += "Velocity, ";
	else if ($("#modifyVelocity").val() <= 0)			//If not empty, check if it is 0 or less
		numErr += "Velocity, ";
	
	if(intervalFlag == 1){	//Interval settings only matter if intervals are used
		if($("#modifyStops").val() == "")				//Check if the Number of Intervals is empty
			err += "Number of Intervals, ";
		else if ($("#modifyStops").val() <= 0)			//If not empty, check if it is 0 or less
			numErr += "Number of Intervals, ";
		
		if($("#modifyIntervalDistance").val() == "")	//Check if the Distance per Intervals is empty
			err += "Distance per Interval, ";
		else if ($("#modifyIntervalDistance").val() <= 0)	//If not empty, check if it is 0 or less
			numErr += "Distance per Interval, ";
		
		if($("#modifyTimeInterval").val() == "")		//Check if the Time between Intervals is empty
			err += "Time between Intervals, ";
		else if ($("#modifyTimeInterval").val() <= 0)	//If not empty, check if it is 0 or less
			numErr += "Time between Intervals, ";
	}
	
	if(err != "" || optErr != "" || numErr != "") {		//If there were any errors specified
		if(err != ""){
			err = err.slice(0, -2) + " must be specified.";	//Format the error
			if(numErr != "")
				err += "\n";
		}
		if(numErr != "")
			numErr = numErr.slice(0, -2) + " must be greater than 0.";	//Format number errors
		alert(optErr + err + numErr);		//Alert the user
		return;
	}
	
	if($("#modifyLuxActivated").prop("checked") == false)	//Convert Lux Sensor flag checkbox status to integer
		var luxActivated = 0;
	else
		var luxActivated = 1;
	
	if($("#modifyCo2Activated").prop("checked") == false)	//Convert CO2 Sensor flag checkbox status to integer
		var co2Activated = 0;
	else
		var co2Activated = 1;
	
	if($("#modifyParticleActivated").prop("checked") == false)	//Convert Particle Sensor flag checkbox status to integer
		var particleActivated = 0;
	else
		var particleActivated = 1;
	
	if($("#modifyHumidityActivated").prop("checked") == false)	//Convert Humidity Sensor flag checkbox status to integer
		var humidityActivated = 0;
	else
		var humidityActivated = 1;
	
	if($("#modifyTemperatureActivated").prop("checked") == false)	//Convert Temperature Sensor flag checkbox status to integer
		var temperatureActivated = 0;
	else
		var temperatureActivated = 1;
	
	$.ajax({
		type: "POST",
		url: "/bots/execute",
		contentType: "application/json",
		data: JSON.stringify({	
			runName: $("#runNameInput").val(),
			botName: $("#botNameInput").val(),
			option: parseInt($("#modifyOption").val()),
			railLength: parseFloat($("#modifyRailLength").val()),
			spoolRadius: parseFloat($("#modifySpoolRadius").val()),
			velocity: parseFloat($("#modifyVelocity").val()),
			intervalFlag: intervalFlag,
			intervalDistance: parseFloat($("#modifyIntervalDistance").val()),
			stops: parseInt($("#modifyStops").val()),
			luxActivated: luxActivated,
			co2Activated: co2Activated,
			particleActivated: particleActivated,
			humidityActivated: humidityActivated,
			temperatureActivated: temperatureActivated,
			timeInterval: parseInt($("#modifyTimeInterval").val())
		}),
		success: function(){	//Once the server is finished loading the config file, fill in the fields
			alert("Run execution successful.");
		},
		dataType: "json"
	}).fail(function(){
		alert("Run execution failed. Please check bot connection.");
	});
}