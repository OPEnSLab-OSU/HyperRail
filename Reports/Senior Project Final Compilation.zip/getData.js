//Creating a data entry in the runs database
router.post('/create', (req, res) => {
    const client = db.get();

    // Format data for database
    const formatData = [{
        fields: {
            value: JSON.stringify(req.body.data)
        },
        tags: {
            botName: req.body.botName,
            runName: req.body.runName
        },
        timestamp: new Date()
    }];

    // Save live data
    saveLiveData(req.body.data);

    // Write to database
    client.writeMeasurement(measure, formatData)
        .then(() => {
            logger.ok("Data uploaded to database");
            const msg = logger.buildPayload(logger.level.OK, 'Data uploaded');
            const status = 201;
            res.status(status).send(msg);
        })
        .catch((err) => {
            logger.error(err);
            const msg = logger.buildPayload(logger.level.ERROR, 'Error uploading');
            const status = 500;
            res.status(status).send(msg);
        });
});